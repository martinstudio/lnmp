#ifndef PHP_CDB_H
#define PHP_CDB_H

#if DBA_CDB

#include "php_dba.h"

DBA_FUNCS(cdb);

#endif

#endif
