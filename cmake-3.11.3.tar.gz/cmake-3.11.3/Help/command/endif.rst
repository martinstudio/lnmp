endif
-----

Ends a list of commands in an if block.

::

  endif(expression)

See the :command:`if` command.
