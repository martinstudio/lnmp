.. cmake-module:: ../../Modules/SelectLibraryConfigurations.cmake
