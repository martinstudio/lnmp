CTEST_INTERACTIVE_DEBUG_MODE
----------------------------

Environment variable that will exist and be set to ``1`` when a test executed
by CTest is run in interactive mode.
